/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_woocommerce_order_items`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_woocommerce_order_items`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_woocommerce_order_items` ( `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `order_item_name` text NOT NULL, `order_item_type` varchar(200) NOT NULL DEFAULT '', `order_id` bigint(20) unsigned NOT NULL, PRIMARY KEY (`order_item_id`), KEY `order_id` (`order_id`)) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1678405783_wpjr_woocommerce_order_items` (`order_item_id`, `order_item_name`, `order_item_type`, `order_id`) VALUES (1,'Banana','line_item',5842),(2,'Banana','line_item',5997),(3,'Red apple','line_item',5997),(4,'Carrot','line_item',5999),(5,'Delicious meat','line_item',6109),(6,'Carrot','line_item',6110),(7,'Refyl Starta','line_item',6229),(8,'Banana','line_item',6231),(9,'Delicious meat','line_item',6236),(10,'Carrot','line_item',6236),(11,'Refyl Standard','line_item',6268),(12,'Beef','line_item',6319),(13,'Water','line_item',6319),(14,'Refyl Starta','line_item',6319),(15,'Apple','line_item',6319);
