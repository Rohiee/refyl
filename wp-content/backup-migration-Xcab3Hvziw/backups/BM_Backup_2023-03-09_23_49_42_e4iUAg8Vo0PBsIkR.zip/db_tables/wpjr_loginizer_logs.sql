/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_loginizer_logs`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_loginizer_logs`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_loginizer_logs` ( `username` varchar(255) NOT NULL DEFAULT '', `time` int(10) NOT NULL DEFAULT 0, `count` int(10) NOT NULL DEFAULT 0, `lockout` int(10) NOT NULL DEFAULT 0, `ip` varchar(255) NOT NULL DEFAULT '', `url` varchar(255) NOT NULL DEFAULT '', UNIQUE KEY `ip` (`ip`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
