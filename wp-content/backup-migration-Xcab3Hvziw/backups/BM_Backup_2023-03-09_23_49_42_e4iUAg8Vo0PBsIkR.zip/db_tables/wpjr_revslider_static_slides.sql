/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_revslider_static_slides`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_revslider_static_slides`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_revslider_static_slides` ( `id` int(9) NOT NULL AUTO_INCREMENT, `slider_id` int(9) NOT NULL, `params` longtext NOT NULL, `layers` longtext NOT NULL, `settings` text NOT NULL, PRIMARY KEY (`id`), KEY `slider_id_index` (`slider_id`)) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
INSERT INTO `1678405783_wpjr_revslider_static_slides` (`id`, `slider_id`, `params`, `layers`, `settings`) VALUES (1,1,'{\"version\":\"\",\"bg\":{\"image\":\"\"},\"image\":\"\"}','[]','{\"temp\":true}');
