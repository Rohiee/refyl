/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_revslider_slides_bkp`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_revslider_slides_bkp`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_revslider_slides_bkp` ( `id` int(9) NOT NULL AUTO_INCREMENT, `slider_id` int(9) NOT NULL, `slide_order` int(11) NOT NULL, `params` longtext NOT NULL, `layers` longtext NOT NULL, `settings` text NOT NULL DEFAULT '', PRIMARY KEY (`id`), KEY `slider_id_index` (`slider_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
