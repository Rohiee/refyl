/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_yith_wcwl`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_yith_wcwl`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_yith_wcwl` ( `ID` bigint(20) NOT NULL AUTO_INCREMENT, `prod_id` bigint(20) NOT NULL, `quantity` int(11) NOT NULL, `user_id` bigint(20) DEFAULT NULL, `wishlist_id` bigint(20) DEFAULT NULL, `position` int(11) DEFAULT 0, `original_price` decimal(9,3) DEFAULT NULL, `original_currency` char(3) DEFAULT NULL, `dateadded` timestamp NOT NULL DEFAULT current_timestamp(), `on_sale` tinyint(4) NOT NULL DEFAULT 0, PRIMARY KEY (`ID`), KEY `prod_id` (`prod_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
