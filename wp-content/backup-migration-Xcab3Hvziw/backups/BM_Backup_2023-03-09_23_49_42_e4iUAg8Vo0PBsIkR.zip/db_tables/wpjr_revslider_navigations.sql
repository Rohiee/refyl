/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_revslider_navigations`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_revslider_navigations`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_revslider_navigations` ( `id` int(9) NOT NULL AUTO_INCREMENT, `name` varchar(191) NOT NULL, `handle` varchar(191) NOT NULL, `type` varchar(191) NOT NULL, `css` longtext NOT NULL, `markup` longtext NOT NULL, `settings` longtext DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
