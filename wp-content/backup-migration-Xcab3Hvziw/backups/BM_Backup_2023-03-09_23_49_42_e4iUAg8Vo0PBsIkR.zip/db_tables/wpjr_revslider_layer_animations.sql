/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_revslider_layer_animations`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_revslider_layer_animations`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_revslider_layer_animations` ( `id` int(9) NOT NULL AUTO_INCREMENT, `handle` text NOT NULL, `params` text NOT NULL, `settings` text DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
