/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_wc_category_lookup`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_wc_category_lookup`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_wc_category_lookup` ( `category_tree_id` bigint(20) unsigned NOT NULL, `category_id` bigint(20) unsigned NOT NULL, PRIMARY KEY (`category_tree_id`,`category_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1678405783_wpjr_wc_category_lookup` (`category_tree_id`, `category_id`) VALUES (30,30),(31,31),(40,40),(41,41),(48,48),(64,64),(65,65),(70,70);
