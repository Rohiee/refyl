/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_woocommerce_shipping_zones`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_woocommerce_shipping_zones`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_woocommerce_shipping_zones` ( `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `zone_name` varchar(200) NOT NULL, `zone_order` bigint(20) unsigned NOT NULL, PRIMARY KEY (`zone_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
