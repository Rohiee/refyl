/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_revslider_sliders_bkp`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_revslider_sliders_bkp`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_revslider_sliders_bkp` ( `id` int(9) NOT NULL AUTO_INCREMENT, `title` tinytext NOT NULL, `alias` tinytext DEFAULT NULL, `params` longtext NOT NULL, `settings` text DEFAULT NULL, `type` varchar(191) NOT NULL DEFAULT '', PRIMARY KEY (`id`), KEY `type_index` (`type`(8))) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
