/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_e_events`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_e_events`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_e_events` ( `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `event_data` text DEFAULT NULL, `created_at` datetime NOT NULL, PRIMARY KEY (`id`), KEY `created_at_index` (`created_at`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1678405783_wpjr_e_events` (`id`, `event_data`, `created_at`) VALUES (1,'{\"event\":\"modal load\",\"version\":\"\",\"details\":\"{\\\"placement\\\":\\\"Onboarding wizard\\\",\\\"step\\\":\\\"account\\\",\\\"user_state\\\":\\\"anon\\\"}\",\"ts\":\"2022-09-06T01:59:51.993-02:00\"}','2022-09-06 01:59:51'),(2,'{\"event\":\"close modal\",\"version\":\"\",\"details\":\"{\\\"placement\\\":\\\"Onboarding wizard\\\",\\\"step\\\":\\\"account\\\"}\",\"ts\":\"2022-09-06T01:59:54.604-02:00\"}','2022-09-06 01:59:54');
