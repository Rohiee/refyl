/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpjr_yith_wcwl_lists`; */
/* PRE_TABLE_NAME: `1678405783_wpjr_yith_wcwl_lists`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678405783_wpjr_yith_wcwl_lists` ( `ID` bigint(20) NOT NULL AUTO_INCREMENT, `user_id` bigint(20) DEFAULT NULL, `session_id` varchar(255) DEFAULT NULL, `wishlist_slug` varchar(200) NOT NULL, `wishlist_name` text DEFAULT NULL, `wishlist_token` varchar(64) NOT NULL, `wishlist_privacy` tinyint(1) NOT NULL DEFAULT 0, `is_default` tinyint(1) NOT NULL DEFAULT 0, `dateadded` timestamp NOT NULL DEFAULT current_timestamp(), `expiration` timestamp NULL DEFAULT NULL, PRIMARY KEY (`ID`), UNIQUE KEY `wishlist_token` (`wishlist_token`), KEY `wishlist_slug` (`wishlist_slug`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
